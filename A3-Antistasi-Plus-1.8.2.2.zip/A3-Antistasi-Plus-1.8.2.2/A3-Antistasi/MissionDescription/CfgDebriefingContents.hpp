// In map template description.ext use:
// #include "MissionDescription\CfgDebriefingContents.hpp"

#include "endMission.hpp"
