// In map template description.ext use:
// #include "MissionDescription\CfgFunctionsContents.hpp"

#define HALs_DEF_FUNCTIONS
		#include "..\HALs\Addons\main\config.hpp"
#undef HALs_DEF_FUNCTIONS

#include "..\functions.hpp"
#include "..\JeroenArsenal\functions.hpp"
#include "..\Garage\functions.hpp"
//#include "..\Collections\functions.hpp"
#include "..\SCRT\functions.hpp"