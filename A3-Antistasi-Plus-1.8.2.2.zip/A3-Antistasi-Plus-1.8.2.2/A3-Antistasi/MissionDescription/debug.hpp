allowFunctionsLog = 1;
enableDebugConsole[] = {
    "76561197993477748"
};
allowFunctionsRecompile = 1;
