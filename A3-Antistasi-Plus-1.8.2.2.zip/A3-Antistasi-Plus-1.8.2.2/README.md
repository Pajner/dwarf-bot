<div align="center">
  <h1>Antistasi Plus</h1>
  <p>
        Antistasi Plus is a fork version of Antistasi mission by Official Antistasi Community.
  </p>
</div>

### Credits
- Original Mission by barbolani
- Antistasi Community Edition by Official Antistasi Community
- Magrepack by Outlawled, R3vo and OOster
- HALs_Store by HallyG, R3vo and barman75
- DRO by mbrdmn
- Discord Rich Presence by ConnorAU 
- Antistasi Plus fork by Socrates
