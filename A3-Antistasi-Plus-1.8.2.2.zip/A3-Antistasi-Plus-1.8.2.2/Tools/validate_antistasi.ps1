python .\sqfvalidator\sqflint.py -d "..\A3-Antistasi" | Tee-Object -FilePath ".\ValidationResults.txt"
Read-Host -Prompt "Press Enter to exit"